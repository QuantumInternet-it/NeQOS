"""Dynamic child composition without device operations or private engine access."""

from NodeEnginePack.NodeEngineAuxiliary import StageResult


async def AuthoringDynamicHoldStage(ctx, params):
    runtime_id = ctx.get("holdRuntimeId")
    if runtime_id is None:
        try:
            runtime_id = ctx.submit_microprotocol(
                "HoldDuration",
                sharedParamOverrides={"durationSec": params["durationSec"]},
            )
        except (KeyError, ValueError) as exc:
            return StageResult("fail", reason=str(exc))
        ctx.set("holdRuntimeId", runtime_id)
        return StageResult("requeue", delaySec=0.05)

    state = ctx.microprotocol_state(runtime_id)
    if state is None or ctx.microprotocol_failed(runtime_id):
        return StageResult("fail", reason=f"Hold child {runtime_id}: state={state}")
    if not ctx.microprotocol_succeeded(runtime_id):
        return StageResult("requeue", delaySec=0.05)
    try:
        result = ctx.child_output(runtime_id, "execution.control.status.holdDuration")
    except ValueError as exc:
        return StageResult("fail", reason=str(exc))
    ctx.set("holdResult", result)
    return StageResult("advance")


HANDLERS = {"AuthoringDynamicHoldStage": AuthoringDynamicHoldStage}
